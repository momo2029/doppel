import './assets/index.ts-C_rDIP_r.js';
