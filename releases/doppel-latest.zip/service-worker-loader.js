import './assets/index.ts-C5GMN_k2.js';
